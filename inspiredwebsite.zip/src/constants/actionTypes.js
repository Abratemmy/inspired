export const CREATE = 'CREATE';
export const UPDATE = "UPDATE";
export const DELETE = "DELETE";
export const FETCH_ALL = "FETCH_ALL";
export const FETCH_POST = "FETCH_POST";
export const COMMENT = "COMMENT";
export const SELECTED_POST= "SELECTED_POST";

export const AUTH = 'AUTH';
export const LOGOUT = "LOGOUT"